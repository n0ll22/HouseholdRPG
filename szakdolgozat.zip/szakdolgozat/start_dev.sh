#start server and client developement
wt new-tab -d ./server bash -c "npm i && npm run dev"
wt new-tab -d ./client bash -c "npm i && npm run dev"
